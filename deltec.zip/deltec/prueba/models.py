from django.db import models
from django.forms import ModelForm

class Persona(models.Model):
    cedula =models.IntegerField(unique = True)
    nombre = models.CharField(max_length=80)
    apellido= models.CharField(max_length=80)
    correo =models.CharField(max_length=200)

    # def __str__(self):
    #     return self.id
        

class Recursos(models.Model):
    codigo = models.CharField(max_length=200, unique = True)
    serie = models.CharField(max_length=200, unique = True)
    categoria = models.CharField(max_length=200)
    marca = models.CharField(max_length=200)
    nombre = models.CharField(max_length=200)
    proveedor = models.CharField(max_length=200)
    # estado = models.BooleanField(defaul = True)

    def __str__(self):
        return self.nombre

class Persona_Recurso(models.Model):
    fecha = models.DateTimeField('date published')
    personal = models.ForeignKey(Persona, on_delete=models.CASCADE)
    recurso = models.ForeignKey(Recursos, on_delete=models.CASCADE)

    # def __str__(self):
    #     return 'self.personal'

class PersonaForm(ModelForm):
    class Meta:
        model = Persona
        fields = '__all__'
       
class RecursosForm(ModelForm):
    class Meta:
        model = Recursos
        fields = '__all__'

class Persona_RecursoForm(ModelForm):
    class Meta:
        model = Persona_Recurso
        fields = '__all__'