from django.apps import AppConfig


class PruebaConfig(AppConfig):
    name = 'prueba'
