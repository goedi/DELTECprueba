from django.http  import  HttpResponse, HttpResponseRedirect
from django.forms import formset_factory
from django.http import Http404
from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from prueba.models import PersonaForm, RecursosForm, Persona_RecursoForm, Persona, Recursos, Persona_Recurso 

def index(request):
    return render(request, 'prueba/index.html')

def registroPersonal(request):
    form = PersonaForm()
    
    if request.method == 'POST':
        form = PersonaForm(request.POST)
        if form.is_valid():
            post = form.save()
        form = PersonaForm()
    else:
        form = PersonaForm()
    return render(request, 'prueba/personal.html',  {'formset': form})

def registroRecursos(request):
    form = RecursosForm()
    print(request.POST)
    if request.method == 'POST':
        form = RecursosForm(request.POST)
        if form.is_valid():
            post = form.save()
        form = RecursosForm()
    else:
        form = RecursosForm()
    return render(request, 'prueba/recursos.html',  {'formset': form})

def asignar(request):
    recursos = "hola"
    if request.method == 'GET':
        personal = Persona.objects.all()
        recursos = Recursos.objects.all()

    return render(request, 'prueba/asignar.html', {'recursos': recursos, 'personal': personal})

def asignarRecurso(array):
    print(array)

def cambiarRecurso(array):
    print(array)

def historial(request):
    asigancion = Persona_Recurso.objects.all().order_by('-fecha')

    return render(request, 'prueba/historialGeneral.html',{'asignaciones': asigancion})

def historial2(request):
    error=''
    asigancion = [Persona_Recurso]
    if request.method == 'POST':
       
        cedula = request.POST.get('cedula')
        if cedula != '':
            cedula = request.POST.get('cedula')
            persona = Persona.objects.filter(cedula = cedula).first()
            if persona != None:
                asigancion = Persona_Recurso.objects.filter(personal = persona.id).all().order_by('-fecha')
                
            else:
                error = 'El numero de cedula dado no es valido'

    return render(request, 'prueba/historialParticular.html',{'asignaciones': asigancion, 'error': error})
