from django.urls import path

from . import views

app_name = 'prueba'
urlpatterns = [
    path('', views.index, name='index'),
    path('registro/personal/', views.registroPersonal, name='personal'),
    path('registro/recursos/', views.registroRecursos, name='recursos'),
    path('recursos/asignar/', views.asignar, name='asignar'),
    path('recursos/historial/', views.historial, name='historialAsignacion'),
    path('recursos/historial/personal/', views.historial2, name='historialPArticular'),
]